using UnityEngine;

public class PlayerController : MonoBehaviour
{

    public float speed = 15f; // let's set a decent speed as default
    public float dir = 1; // Set right facing sprite. 1 is right 0 is left.
    private Rigidbody2D rb;
    Animator anim;
    private float jumpForce = 5;
    SpriteRenderer spr;
    

    void Start() // Upper case because in C# casing counts!
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        spr = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        float magnitudeX = rb.velocity.x;
        if (moveHorizontal != 0)
        {
            anim.SetBool("isWalking", true);
            Debug.Log(moveHorizontal);
        }
        else
        {
            anim.SetBool("isWalking", false);
            Debug.Log(moveHorizontal);
        }
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            rb.AddForce(transform.up * jumpForce, ForceMode2D.Impulse);
            anim.SetTrigger("Jump");
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            anim.SetTrigger("Attack");
        }

        if (moveHorizontal < 0)
        {
            spr.flipX = true;
            dir = 0;
            Debug.Log(dir);
        }
        else if (moveHorizontal > 0)
        {
            spr.flipX = false;
            dir = 1;
            Debug.Log(dir);
        }
        // Let's assign both x and z
        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
        rb.AddForce(movement * speed);

    }
}
