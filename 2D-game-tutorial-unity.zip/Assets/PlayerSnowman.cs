using UnityEngine;
using UnityEngine.Events;

public class PlayerSnowman : MonoBehaviour
{
    public int NumberOfSnowman { get; private set; }

    public UnityEvent<PlayerSnowman> OnSnowmanCollected;

    public void SnowmanCollected()
    {
        NumberOfSnowman++;
        OnSnowmanCollected.Invoke(this);
    }
}