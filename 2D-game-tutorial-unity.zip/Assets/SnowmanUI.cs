using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SnowmanUI : MonoBehaviour
{
    private TextMeshProUGUI snowmanNumber;
    // Start is called before the first frame update
    void Start()
    {
        snowmanNumber = GetComponent<TextMeshProUGUI>();
    }

    public void UpdateSnowmanNumber(PlayerSnowman playerSnowman)
    {
        snowmanNumber.text = playerSnowman.NumberOfSnowman.ToString();
    }
}
