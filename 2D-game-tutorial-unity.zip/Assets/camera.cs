using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public GameObject Player;
    Vector3 pos = Vector3.zero;

    void Start()
    {
        pos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {

        pos.x = Player.transform.position.x;
        transform.position = pos;

    }
}