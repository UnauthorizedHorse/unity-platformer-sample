
using UnityEngine;

public class Snowman : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        PlayerSnowman playerSnowman = other.GetComponent<PlayerSnowman>();

        if (playerSnowman != null)
        {
            playerSnowman.SnowmanCollected();
            gameObject.SetActive(false);
        }
    }
}
